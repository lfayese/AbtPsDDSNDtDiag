$PropertyNames = @("Cost", "Date", "Name")

New-PSItem 1.1  1/1/2015 John $PropertyNames
New-PSItem 2.1  1/2/2015 Tom
New-PSItem 5.1  1/2/2015 Dick
New-PSItem 11.1 1/2/2015 Harry
New-PSItem 7.1  1/2/2015 Jane
New-PSItem 22.1 1/2/2015 Mary
New-PSItem 32.1 1/2/2015 Liz
